import json
import os
import re

def main():
    if not os.path.exists("full_scraped_cards.json"):
        print("Scraped file not ready yet")
        return

    with open("full_scraped_cards.json", "r", encoding="utf-8") as f:
        cards_db = json.load(f)

    print(f"Loaded {len(cards_db)} cards from json")

    # Clean up HTML entities
    for cid, c in cards_db.items():
        if "name" in c and c["name"]:
            c["name"] = c["name"].replace('&amp;', '&').replace('&quot;', '"').replace('&#039;', "'").replace('&lt;', '<').replace('&gt;', '>')
        if "traits" in c and c["traits"]:
            c["traits"] = c["traits"].replace('&amp;', '&').replace('&quot;', '"').replace('&#039;', "'").replace('&lt;', '<').replace('&gt;', '>')

    js_code = f"""// Comprehensive One Piece TCG Cards Database & Fallback Engine
// Scraped & Verified from Official Bandai / Limitless TCG Database

const ONE_PIECE_CARDS_DB = {json.dumps(cards_db, ensure_ascii=False, indent=2)};

const STARTER_DECK_COLORS = {{
  "ST01": "Red",
  "ST02": "Green",
  "ST03": "Blue",
  "ST04": "Purple",
  "ST05": "Purple",
  "ST06": "Black",
  "ST07": "Yellow",
  "ST08": "Black",
  "ST09": "Yellow",
  "ST10": "Red/Purple",
  "ST11": "Green",
  "ST12": "Green/Blue",
  "ST13": "Yellow",
  "ST14": "Black",
  "ST15": "Red",
  "ST16": "Green",
  "ST17": "Blue",
  "ST18": "Purple",
  "ST19": "Black",
  "ST20": "Yellow",
  "ST21": "Red",
  "ST22": "Green",
  "ST23": "Blue",
  "ST24": "Black",
  "ST25": "Red",
  "ST26": "Green",
  "ST27": "Black",
  "ST28": "Blue"
}};

function determineCardColor(cardId) {{
  if (!cardId) return 'Red';
  const clean = cardId.toUpperCase().trim();

  // Si ya está en la base de datos oficial
  if (ONE_PIECE_CARDS_DB[clean] && ONE_PIECE_CARDS_DB[clean].color) {{
    return ONE_PIECE_CARDS_DB[clean].color;
  }}

  const parts = clean.split('-');
  if (parts.length < 2) return 'Red';

  const setCode = parts[0];
  const num = parseInt(parts[1], 10) || 1;

  // Starters ST01 - ST28
  if (STARTER_DECK_COLORS[setCode]) {{
    return STARTER_DECK_COLORS[setCode];
  }}

  // OP-01 Romance Dawn (Red, Green, Blue, Purple)
  if (setCode === 'OP01') {{
    if (num <= 29) return 'Red';
    if (num <= 59) return 'Green';
    if (num <= 90) return 'Blue';
    return 'Purple';
  }}

  // OP-02 Paramount War (Red, Green, Blue, Purple, Black)
  if (setCode === 'OP02') {{
    if (num <= 24) return 'Red';
    if (num <= 48) return 'Green';
    if (num <= 70) return 'Blue';
    if (num <= 92) return 'Purple';
    return 'Black';
  }}

  // OP-03 Pillars of Strength (Red, Green, Blue, Purple, Black, Yellow)
  if (setCode === 'OP03') {{
    if (num <= 20) return 'Red';
    if (num <= 39) return 'Green';
    if (num <= 57) return 'Blue';
    if (num <= 75) return 'Purple';
    if (num <= 98) return 'Black';
    return 'Yellow';
  }}

  // OP-04 Kingdoms of Intrigue
  if (setCode === 'OP04') {{
    if (num <= 19) return 'Red';
    if (num <= 38) return 'Green';
    if (num <= 57) return 'Blue';
    if (num <= 76) return 'Purple';
    if (num <= 98) return 'Black';
    return 'Yellow';
  }}

  // OP-05 Awakening of the New Era
  if (setCode === 'OP05') {{
    if (num <= 19) return 'Red';
    if (num <= 39) return 'Green';
    if (num <= 59) return 'Blue';
    if (num <= 79) return 'Purple';
    if (num <= 97) return 'Black';
    return 'Yellow';
  }}

  // OP-06 Wings of the Captain
  if (setCode === 'OP06') {{
    if (num <= 19) return 'Red';
    if (num <= 40) return 'Green';
    if (num <= 59) return 'Blue';
    if (num <= 79) return 'Purple';
    if (num <= 99) return 'Black';
    return 'Yellow';
  }}

  // OP-07 500 Years in the Future
  if (setCode === 'OP07') {{
    if (num <= 18) return 'Red';
    if (num <= 37) return 'Green';
    if (num <= 58) return 'Blue';
    if (num <= 78) return 'Purple';
    if (num <= 96) return 'Black';
    return 'Yellow';
  }}

  // OP-08 Two Legends
  if (setCode === 'OP08') {{
    if (num <= 18) return 'Red';
    if (num <= 37) return 'Green';
    if (num <= 56) return 'Blue';
    if (num <= 77) return 'Purple';
    if (num <= 97) return 'Black';
    return 'Yellow';
  }}

  // OP-09 Emperors in the New World
  if (setCode === 'OP09') {{
    if (num <= 20) return 'Red';
    if (num <= 40) return 'Green';
    if (num <= 60) return 'Blue';
    if (num <= 80) return 'Purple';
    if (num <= 98) return 'Black';
    return 'Yellow';
  }}

  // OP-10 Royal Bloodlines
  if (setCode === 'OP10') {{
    if (num <= 20) return 'Red';
    if (num <= 40) return 'Green';
    if (num <= 60) return 'Blue';
    if (num <= 80) return 'Purple';
    if (num <= 98) return 'Black';
    return 'Yellow';
  }}

  // OP-17 The World's Strongest Warriors
  if (setCode === 'OP17') {{
    if (num <= 20) return 'Red';
    if (num <= 38) return 'Green';
    if (num <= 60) return 'Blue';
    if (num <= 78) return 'Purple';
    if (num <= 98) return 'Black';
    return 'Yellow';
  }}

  // EB-01 Memorial Collection
  if (setCode === 'EB01') {{
    if (num <= 10) return 'Red';
    if (num <= 20) return 'Green';
    if (num <= 32) return 'Blue';
    if (num <= 44) return 'Purple';
    if (num <= 54) return 'Black';
    return 'Yellow';
  }}

  return 'Red';
}}

function getCardImageURLs(cardId) {{
  if (!cardId) return [];
  const cleanId = cardId.toUpperCase().trim();
  const setCode = cleanId.split('-')[0];

  return [
    `https://limitlesstcg.nyc3.cdn.digitaloceanspaces.com/one-piece/${{setCode}}/${{cleanId}}_EN.webp`,
    `https://limitlesstcg.nyc3.cdn.digitaloceanspaces.com/one-piece/${{setCode}}/${{cleanId}}.webp`,
    `https://limitlesstcg.nyc3.cdn.digitaloceanspaces.com/one-piece/${{setCode}}/${{cleanId}}_JP.webp`,
    `https://en.onepiece-cardgame.com/images/cardlist/card/${{cleanId}}.png`
  ];
}}

function createGenericCard(cardId) {{
  const cleanId = cardId.toUpperCase().trim();
  const color = determineCardColor(cleanId);
  const parts = cleanId.split('-');
  const setCode = parts[0] || 'OP01';
  const num = parseInt(parts[1], 10) || 1;

  let cardType = 'Character';
  let rarity = 'R';
  if (num === 1 && (setCode.startsWith('OP') || setCode.startsWith('ST'))) {{
    cardType = 'Leader';
    rarity = 'L';
  }}

  let traits = 'One Piece Pirates';
  if (STARTER_DECK_COLORS[setCode]) {{
    if (setCode === 'ST27' || setCode === 'ST24') traits = 'The Four Emperors / Blackbeard Pirates';
    else if (setCode === 'ST01' || setCode === 'ST08' || setCode === 'ST14' || setCode === 'ST25') traits = 'Straw Hat Crew';
    else if (setCode === 'ST06' || setCode === 'ST19') traits = 'Navy';
    else if (setCode === 'ST07' || setCode === 'ST20') traits = 'Big Mom Pirates';
    else if (setCode === 'ST21') traits = 'Red Hair Pirates';
    else if (setCode === 'ST22' || setCode === 'ST15') traits = 'Whitebeard Pirates';
    else if (setCode === 'ST23' || setCode === 'ST28') traits = 'Cross Guild';
  }}

  return {{
    id: cleanId,
    name: `Carta ${{cleanId}}`,
    set: `Set ${{setCode}}`,
    cardType: cardType,
    color: color,
    traits: traits,
    rarity: rarity,
    cost: '4 Cost / 5000 Power',
    imageFallbacks: getCardImageURLs(cleanId)
  }};
}}

function findOrGenerateCard(query) {{
  if (!query) return createGenericCard('OP01-001');
  const clean = query.toUpperCase().trim();

  if (ONE_PIECE_CARDS_DB[clean]) {{
    const dbCard = ONE_PIECE_CARDS_DB[clean];
    return {{
      ...dbCard,
      set: dbCard.set || `Set ${{clean.split('-')[0]}}`,
      imageFallbacks: getCardImageURLs(clean)
    }};
  }}

  for (const [id, c] of Object.entries(ONE_PIECE_CARDS_DB)) {{
    if (c.name && c.name.toLowerCase() === query.toLowerCase().trim()) {{
      return {{
        ...c,
        set: c.set || `Set ${{id.split('-')[0]}}`,
        imageFallbacks: getCardImageURLs(id)
      }};
    }}
  }}

  return createGenericCard(clean);
}}

function generateFallbackCardSVG(card) {{
  const colorMap = {{
    'Red': '#dc2626',
    'Green': '#16a34a',
    'Blue': '#2563eb',
    'Purple': '#9333ea',
    'Black': '#1e293b',
    'Yellow': '#ca8a04',
    'Red/Purple': '#dc2626',
    'Green/Blue': '#16a34a',
    'Blue/Black': '#2563eb'
  }};
  
  const primaryColor = (card.color || 'Red').split('/')[0];
  const bgHex = colorMap[primaryColor] || '#2563eb';
  const name = (card.name || card.id).slice(0, 20);
  const type = card.cardType || 'Character';

  const svg = `
    <svg xmlns="http://www.w3.org/2000/svg" width="300" height="420" viewBox="0 0 300 420">
      <defs>
        <linearGradient id="g" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stop-color="${{bgHex}}" />
          <stop offset="100%" stop-color="#0a0f1d" />
        </linearGradient>
      </defs>
      <rect width="300" height="420" rx="16" fill="url(#g)" stroke="#f59e0b" stroke-width="4"/>
      <circle cx="150" cy="160" r="70" fill="rgba(0,0,0,0.4)" stroke="#f59e0b" stroke-width="2"/>
      <text x="150" y="175" font-size="50" text-anchor="middle" fill="#f59e0b">🏴‍☠️</text>
      <rect x="20" y="260" width="260" height="50" rx="8" fill="rgba(0,0,0,0.7)" />
      <text x="150" y="292" font-size="16" font-family="sans-serif" font-weight="bold" fill="#ffffff" text-anchor="middle">${{name}}</text>
      <text x="150" y="340" font-size="20" font-family="monospace" font-weight="bold" fill="#f59e0b" text-anchor="middle">${{card.id}}</text>
      <text x="150" y="375" font-size="13" font-family="sans-serif" fill="#94a3b8" text-anchor="middle">${{type}} • ${{card.color}}</text>
    </svg>
  `;
  return `data:image/svg+xml;utf8,${{encodeURIComponent(svg)}}`;
}}

if (typeof window !== 'undefined') {{
  window.ONE_PIECE_CARDS_DB = ONE_PIECE_CARDS_DB;
  window.findOrGenerateCard = findOrGenerateCard;
  window.getCardImageURLs = getCardImageURLs;
  window.generateFallbackCardSVG = generateFallbackCardSVG;
  window.determineCardColor = determineCardColor;
}}
"""

    with open("cards-data.js", "w", encoding="utf-8") as f:
        f.write(js_code)
    
    with open("one piece tcg scanner/cards-data.js", "w", encoding="utf-8") as f:
        f.write(js_code)

    print("cards-data.js generated successfully in both locations!")

if __name__ == "__main__":
    main()
