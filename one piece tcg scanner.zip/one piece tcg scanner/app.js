// One Piece TCG Pocket Dex & Collection Manager - Primary Code Entry & Exhaustive Attributes

class OnePieceApp {
  constructor() {
    this.collection = [];
    this.activeFilter = 'ALL';
    this.searchQuery = '';
    this.currentTab = 'album';
    this.pendingCard = null;
    this.pendingQty = 1;

    this.init();
  }

  init() {
    this.loadCollection();
    this.cacheDOM();
    this.bindEvents();
    this.renderAlbum();
    this.updateHeaderStats();
  }

  loadCollection() {
    try {
      const raw = localStorage.getItem('op_tcg_cards_v7');
      if (raw) {
        this.collection = JSON.parse(raw);
        // Sincronizar atributos exactos (Color, Traits, Tipo, Rareza, Coste) con la base de datos oficial
        this.collection.forEach(c => {
          const fresh = findOrGenerateCard(c.id);
          c.name = (c.name && !c.name.startsWith("Carta ")) ? c.name : fresh.name;
          c.color = fresh.color;
          c.cardType = fresh.cardType;
          c.traits = (c.traits && c.traits !== 'One Piece Pirates') ? c.traits : fresh.traits;
          c.rarity = fresh.rarity;
          c.cost = fresh.cost;
          c.set = fresh.set;
        });
      } else {
        this.collection = [
          { ...findOrGenerateCard("OP17-039"), count: 1, addedAt: new Date().toLocaleDateString() }, // Rocks.D.Xebec Leader (Azul, Rocks Pirates)
          { ...findOrGenerateCard("OP17-118"), count: 1, addedAt: new Date().toLocaleDateString() }, // Rocks.D.Xebec SEC (Azul, Rocks Pirates)
          { ...findOrGenerateCard("OP17-001"), count: 1, addedAt: new Date().toLocaleDateString() }, // Gol.D.Roger Leader (Rojo, Roger Pirates)
          { ...findOrGenerateCard("OP09-082"), count: 1, addedAt: new Date().toLocaleDateString() }, // Avalo Pizarro (Negro, Blackbeard Pirates)
          { ...findOrGenerateCard("OP09-118"), count: 1, addedAt: new Date().toLocaleDateString() }, // Gol.D.Roger SEC (Amarillo, Roger Pirates)
          { ...findOrGenerateCard("OP09-021"), count: 2, addedAt: new Date().toLocaleDateString() }  // Edward.Newgate Leader (Verde, Whitebeard Pirates)
        ];
        this.saveCollection();
      }
    } catch (e) {
      console.error("Error al cargar colección:", e);
      this.collection = [];
    }
  }

  saveCollection() {
    try {
      localStorage.setItem('op_tcg_cards_v7', JSON.stringify(this.collection));
    } catch (e) {
      console.error("Error al guardar colección:", e);
    }
    this.updateHeaderStats();
  }

  cacheDOM() {
    this.dom = {
      headerStats: document.getElementById('header-stats'),

      viewAlbum: document.getElementById('view-album'),
      viewScanner: document.getElementById('view-scanner'),
      viewExport: document.getElementById('view-export'),
      navButtons: document.querySelectorAll('.nav-button'),

      albumSearchInput: document.getElementById('album-search-input'),
      albumSearchClear: document.getElementById('album-search-clear'),
      filterPills: document.querySelectorAll('.filter-pill'),
      cardsGrid: document.getElementById('cards-grid'),
      emptyAlbumMsg: document.getElementById('empty-album-msg'),

      // Vista de Entrada por Código
      directCardCodeInput: document.getElementById('direct-card-code-input'),
      btnSubmitCardCode: document.getElementById('btn-submit-card-code'),
      setChips: document.querySelectorAll('.set-chip'),
      exampleChips: document.querySelectorAll('.example-chip'),

      // Modal de Carta
      cardModal: document.getElementById('card-modal'),
      btnCloseModal: document.getElementById('btn-close-modal'),
      modalCardImg: document.getElementById('modal-card-img'),
      modalCardId: document.getElementById('modal-card-id'),
      modalCardColor: document.getElementById('modal-card-color'),
      modalCardName: document.getElementById('modal-card-name'),
      modalCardTraits: document.getElementById('modal-card-traits'),
      modalCardMeta: document.getElementById('modal-card-meta'),
      modalExistingMsg: document.getElementById('modal-existing-msg'),
      modalForecast: document.getElementById('modal-forecast'),
      modalCustomQty: document.getElementById('modal-custom-qty'),
      qtyBtns: document.querySelectorAll('.qty-btn'),
      btnSaveCardToAlbum: document.getElementById('btn-save-card-to-album'),

      // Exportar / Importar
      btnSheetsCopy: document.getElementById('btn-sheets-copy'),
      btnExcelCsv: document.getElementById('btn-excel-csv'),
      importExcelFile: document.getElementById('import-excel-file'),
      btnPasteSheets: document.getElementById('btn-paste-sheets'),
      pasteModal: document.getElementById('paste-modal'),
      pasteTextarea: document.getElementById('paste-textarea'),
      btnConfirmPasteImport: document.getElementById('btn-confirm-paste-import'),
      btnCancelPasteImport: document.getElementById('btn-cancel-paste-import'),
      btnClosePasteModal: document.getElementById('btn-close-paste-modal'),
      btnSaveJson: document.getElementById('btn-save-json'),
      importJsonFile: document.getElementById('import-json-file')
    };
  }

  bindEvents() {
    this.dom.navButtons.forEach(btn => {
      btn.addEventListener('click', () => {
        const tab = btn.getAttribute('data-tab');
        this.switchTab(tab);
      });
    });

    this.dom.albumSearchInput.addEventListener('input', (e) => {
      this.searchQuery = e.target.value.trim().toLowerCase();
      this.dom.albumSearchClear.style.display = this.searchQuery ? 'block' : 'none';
      this.renderAlbum();
    });

    this.dom.albumSearchClear.addEventListener('click', () => {
      this.dom.albumSearchInput.value = '';
      this.searchQuery = '';
      this.dom.albumSearchClear.style.display = 'none';
      this.renderAlbum();
    });

    this.dom.filterPills.forEach(pill => {
      pill.addEventListener('click', () => {
        this.dom.filterPills.forEach(p => p.classList.remove('active'));
        pill.classList.add('active');
        this.activeFilter = pill.getAttribute('data-filter');
        this.renderAlbum();
      });
    });

    // Entrada directa por código
    if (this.dom.btnSubmitCardCode) {
      this.dom.btnSubmitCardCode.addEventListener('click', () => {
        this.submitCodeInput();
      });
    }

    if (this.dom.directCardCodeInput) {
      this.dom.directCardCodeInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          this.submitCodeInput();
        }
      });

      // Asegurar que si el usuario borra todo, comience siempre con "OP"
      this.dom.directCardCodeInput.addEventListener('focus', () => {
        if (!this.dom.directCardCodeInput.value) {
          this.dom.directCardCodeInput.value = 'OP';
        }
      });
    }

    // Atajos de Set
    this.dom.setChips.forEach(chip => {
      chip.addEventListener('click', () => {
        this.dom.setChips.forEach(c => c.classList.remove('active'));
        chip.classList.add('active');
        const prefix = chip.getAttribute('data-set');
        this.dom.directCardCodeInput.value = prefix;
        this.dom.directCardCodeInput.focus();
      });
    });

    // Atajos de Ejemplos
    this.dom.exampleChips.forEach(chip => {
      chip.addEventListener('click', () => {
        const code = chip.getAttribute('data-code');
        if (code) {
          this.dom.directCardCodeInput.value = code;
          this.fetchAndOpenCardModal(code);
        }
      });
    });

    // Modal de Cantidad
    this.dom.qtyBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        this.dom.qtyBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        this.pendingQty = parseInt(btn.getAttribute('data-q')) || 1;
        this.dom.modalCustomQty.value = this.pendingQty;
        this.updateModalForecast();
      });
    });

    this.dom.modalCustomQty.addEventListener('input', (e) => {
      const val = parseInt(e.target.value) || 1;
      this.pendingQty = Math.max(1, val);
      this.dom.qtyBtns.forEach(b => {
        b.classList.toggle('active', parseInt(b.getAttribute('data-q')) === this.pendingQty);
      });
      this.updateModalForecast();
    });

    this.dom.btnSaveCardToAlbum.addEventListener('click', () => {
      if (this.pendingCard) {
        this.addCardToCollection(this.pendingCard, this.pendingQty);
        this.closeModal();
        this.switchTab('album');
      }
    });

    this.dom.btnCloseModal.addEventListener('click', () => this.closeModal());
    this.dom.cardModal.addEventListener('click', (e) => {
      if (e.target === this.dom.cardModal) this.closeModal();
    });

    // Exportar / Importar
    this.dom.btnSheetsCopy.addEventListener('click', () => this.copyToGoogleSheets());
    this.dom.btnExcelCsv.addEventListener('click', () => this.downloadExcelCSV());
    
    if (this.dom.importExcelFile) {
      this.dom.importExcelFile.addEventListener('change', (e) => this.handleExcelCSVImport(e));
    }

    if (this.dom.btnPasteSheets) {
      this.dom.btnPasteSheets.addEventListener('click', () => {
        this.dom.pasteTextarea.value = '';
        this.dom.pasteModal.classList.add('active');
      });
    }

    if (this.dom.btnClosePasteModal) {
      this.dom.btnClosePasteModal.addEventListener('click', () => this.dom.pasteModal.classList.remove('active'));
    }

    if (this.dom.btnCancelPasteImport) {
      this.dom.btnCancelPasteImport.addEventListener('click', () => this.dom.pasteModal.classList.remove('active'));
    }

    if (this.dom.btnConfirmPasteImport) {
      this.dom.btnConfirmPasteImport.addEventListener('click', () => {
        const text = this.dom.pasteTextarea.value;
        if (text && text.trim()) {
          this.parseAndImportDelimitedText(text);
          this.dom.pasteModal.classList.remove('active');
        } else {
          this.showToast("Pega texto de filas primero");
        }
      });
    }

    this.dom.btnSaveJson.addEventListener('click', () => this.exportBackupJSON());
    this.dom.importJsonFile.addEventListener('change', (e) => this.importBackupJSON(e));
  }

  submitCodeInput() {
    const raw = this.dom.directCardCodeInput.value.trim();
    if (!raw || raw === 'OP' || raw === 'ST') {
      this.showToast("Introduce el código de la carta (ej. OP17-039)");
      this.dom.directCardCodeInput.focus();
      return;
    }

    const clean = this.cleanCardCode(raw) || raw;
    this.fetchAndOpenCardModal(clean);
  }

  switchTab(tabName) {
    this.currentTab = tabName;

    this.dom.navButtons.forEach(btn => {
      btn.classList.toggle('active', btn.getAttribute('data-tab') === tabName);
    });

    this.dom.viewAlbum.classList.toggle('active', tabName === 'album');
    this.dom.viewScanner.classList.toggle('active', tabName === 'scanner');
    this.dom.viewExport.classList.toggle('active', tabName === 'export');

    if (tabName === 'scanner') {
      if (this.dom.directCardCodeInput) {
        if (!this.dom.directCardCodeInput.value) {
          this.dom.directCardCodeInput.value = 'OP';
        }
        setTimeout(() => {
          this.dom.directCardCodeInput.focus();
          const len = this.dom.directCardCodeInput.value.length;
          this.dom.directCardCodeInput.setSelectionRange(len, len);
        }, 100);
      }
    }

    if (tabName === 'album') {
      this.renderAlbum();
    }
  }

  cleanCardCode(text) {
    if (!text) return null;
    let clean = text.toUpperCase().replace(/[oO]/g, '0').replace(/[\r\n\t]/g, ' ').trim();

    // Si el usuario escribe directamente "17-039" o "17 039", asumir OP17-039
    const matchSimple = clean.match(/^([0-9]{1,2})\s*[-_ ]\s*([0-9]{1,3})$/);
    if (matchSimple) {
      const setNum = matchSimple[1].padStart(2, '0');
      const cardNum = matchSimple[2].padStart(3, '0');
      return `OP${setNum}-${cardNum}`;
    }

    const match = clean.match(/(OP|ST|EB|PRB)\s*[-_ ]?\s*([0-9]{1,2})\s*[-_ ]\s*([0-9]{1,3})/i);
    if (match) {
      const prefix = match[1].toUpperCase();
      const setNum = match[2].padStart(2, '0');
      const cardNum = match[3].padStart(3, '0');
      return `${prefix}${setNum}-${cardNum}`;
    }

    const matchDirect = clean.match(/(OP|ST|EB|PRB)([0-9]{1,2})([0-9]{3})/i);
    if (matchDirect) {
      return `${matchDirect[1].toUpperCase()}${matchDirect[2].padStart(2, '0')}-${matchDirect[3].padStart(3, '0')}`;
    }

    const matchP = clean.match(/P\s*[-_ ]?\s*([0-9]{3})/i);
    if (matchP) {
      return `P-${matchP[1].padStart(3, '0')}`;
    }

    return null;
  }

  setupRobustImage(imgEl, cardData) {
    const urls = cardData.imageFallbacks || getCardImageURLs(cardData.id);
    let index = 0;

    imgEl.src = urls[0];
    imgEl.onerror = () => {
      index++;
      if (index < urls.length) {
        imgEl.src = urls[index];
      } else {
        imgEl.src = generateFallbackCardSVG(cardData);
      }
    };
  }

  async fetchAndOpenCardModal(query) {
    this.showToast(`Buscando ${query}...`);
    const cardData = findOrGenerateCard(query);
    this.pendingCard = cardData;
    this.pendingQty = 1;

    const existing = this.collection.find(c => c.id === cardData.id);
    const existingCount = existing ? existing.count : 0;

    this.setupRobustImage(this.dom.modalCardImg, cardData);

    this.dom.modalCardId.textContent = cardData.id;
    this.dom.modalCardName.textContent = cardData.name;
    this.dom.modalCardTraits.textContent = cardData.traits || 'One Piece';

    const primaryColor = (cardData.color || 'Blue').split('/')[0];
    this.dom.modalCardColor.textContent = cardData.color;
    this.dom.modalCardColor.className = `color-badge col-${primaryColor}`;

    const costOrLife = cardData.cost ? ` • ${cardData.cost}` : '';
    this.dom.modalCardMeta.textContent = `${cardData.set} • ${cardData.cardType} (${cardData.rarity || 'R'})${costOrLife}`;

    if (existingCount > 0) {
      this.dom.modalExistingMsg.innerHTML = `🟢 <strong>Ya tienes ${existingCount} copias</strong> en tu álbum. ¿Cuántas más quieres sumar?`;
    } else {
      this.dom.modalExistingMsg.innerHTML = `✨ <strong>¡Nueva carta!</strong> Aún no la tenías en tu colección.`;
    }

    this.dom.qtyBtns.forEach(b => {
      b.classList.toggle('active', b.getAttribute('data-q') === '1');
    });
    this.dom.modalCustomQty.value = 1;

    this.updateModalForecast();
    this.dom.cardModal.classList.add('active');
  }

  updateModalForecast() {
    if (!this.pendingCard) return;
    const existing = this.collection.find(c => c.id === this.pendingCard.id);
    const existingCount = existing ? existing.count : 0;
    const newTotal = existingCount + this.pendingQty;

    if (existingCount > 0) {
      this.dom.modalForecast.innerHTML = `Total pasará de <strong>${existingCount}</strong> ➔ <strong>${newTotal} copias</strong>`;
    } else {
      this.dom.modalForecast.innerHTML = `Se guardará con <strong>${newTotal} copias</strong>`;
    }
  }

  closeModal() {
    this.dom.cardModal.classList.remove('active');
    this.pendingCard = null;
  }

  addCardToCollection(cardData, qty) {
    const index = this.collection.findIndex(c => c.id === cardData.id);
    if (index >= 0) {
      this.collection[index].count += qty;
      this.collection[index].updatedAt = new Date().toLocaleDateString();
      this.showToast(`¡Sumadas +${qty} copias! (Total: ${this.collection[index].count})`);
    } else {
      this.collection.unshift({
        ...cardData,
        count: qty,
        addedAt: new Date().toLocaleDateString()
      });
      this.showToast(`¡Añadida ${cardData.name} (x${qty})!`);
    }

    this.saveCollection();
    this.renderAlbum();
  }

  adjustCardCount(cardId, delta) {
    const index = this.collection.findIndex(c => c.id === cardId);
    if (index >= 0) {
      this.collection[index].count += delta;
      if (this.collection[index].count <= 0) {
        if (confirm(`¿Eliminar ${this.collection[index].name} (${this.collection[index].id}) de tu álbum?`)) {
          this.collection.splice(index, 1);
        } else {
          this.collection[index].count = 1;
        }
      }
      this.saveCollection();
      this.renderAlbum();
    }
  }

  renderAlbum() {
    const filtered = this.collection.filter(card => {
      if (this.searchQuery) {
        const q = this.searchQuery;
        const matchName = (card.name || '').toLowerCase().includes(q);
        const matchCode = (card.id || '').toLowerCase().includes(q);
        const matchTraits = (card.traits || '').toLowerCase().includes(q);
        const matchColor = (card.color || '').toLowerCase().includes(q);
        const matchSet = (card.set || '').toLowerCase().includes(q);
        const matchType = (card.cardType || '').toLowerCase().includes(q);
        if (!matchName && !matchCode && !matchTraits && !matchColor && !matchSet && !matchType) return false;
      }

      if (this.activeFilter === 'ALL') return true;

      const matchColor = (card.color || '').toLowerCase().includes(this.activeFilter.toLowerCase());
      const matchTrait = (card.traits || '').toLowerCase().includes(this.activeFilter.toLowerCase());
      const matchType = (card.cardType || '').toLowerCase().includes(this.activeFilter.toLowerCase());
      return matchColor || matchTrait || matchType;
    });

    this.dom.cardsGrid.innerHTML = '';

    if (filtered.length === 0) {
      this.dom.emptyAlbumMsg.style.display = 'block';
    } else {
      this.dom.emptyAlbumMsg.style.display = 'none';

      filtered.forEach(card => {
        const primaryColor = (card.color || 'Red').split('/')[0];
        const cardEl = document.createElement('div');
        cardEl.className = 'card-item';
        
        cardEl.innerHTML = `
          <div class="card-image-wrap">
            <img class="card-img-element" alt="${card.name}" loading="lazy" />
            <span class="card-badge-color col-${primaryColor}">${card.color}</span>
            <span class="card-badge-count">x${card.count}</span>
          </div>
          <div class="card-info-wrap">
            <div style="display:flex; justify-content:space-between; align-items:center;">
              <span class="card-id-text">${card.id}</span>
              <span class="card-type-chip">${card.cardType || 'Card'} • ${card.rarity || 'R'}</span>
            </div>
            <div class="card-name-text" title="${card.name}">${card.name}</div>
            <div class="trait-tag" title="${card.traits || 'One Piece'}">${card.traits || 'One Piece'}</div>
            <div class="card-stepper-row">
              <button class="step-btn btn-sub" data-id="${card.id}">−</button>
              <span class="step-count">${card.count}</span>
              <button class="step-btn btn-add" data-id="${card.id}">+</button>
            </div>
          </div>
        `;

        const imgTag = cardEl.querySelector('.card-img-element');
        this.setupRobustImage(imgTag, card);

        cardEl.querySelector('.btn-sub').addEventListener('click', () => {
          this.adjustCardCount(card.id, -1);
        });

        cardEl.querySelector('.btn-add').addEventListener('click', () => {
          this.adjustCardCount(card.id, 1);
        });

        this.dom.cardsGrid.appendChild(cardEl);
      });
    }

    this.updateHeaderStats();
  }

  updateHeaderStats() {
    const totalCopies = this.collection.reduce((sum, c) => sum + (c.count || 0), 0);
    const uniqueCards = this.collection.length;
    if (this.dom.headerStats) {
      this.dom.headerStats.textContent = `${totalCopies} cartas (${uniqueCards} únicas)`;
    }
  }

  async copyToGoogleSheets() {
    if (this.collection.length === 0) {
      this.showToast("No tienes cartas en la colección");
      return;
    }

    let tsv = "Código\tNombre\tCantidad\tColor\tType / Rasgos\tTipo\tRareza\tCoste/Vida\tExpansión\tFecha\n";
    this.collection.forEach(c => {
      tsv += `${c.id}\t${c.name}\t${c.count}\t${c.color}\t${c.traits || ''}\t${c.cardType || ''}\t${c.rarity || ''}\t${c.cost || ''}\t${c.set || ''}\t${c.addedAt || ''}\n`;
    });

    try {
      await navigator.clipboard.writeText(tsv);
      this.showToast("📋 ¡Copiado! Abre Google Sheets y pulsa Pegar");
    } catch (e) {
      const ta = document.createElement('textarea');
      ta.value = tsv;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
      this.showToast("📋 ¡Copiado para Google Sheets!");
    }
  }

  downloadExcelCSV() {
    if (this.collection.length === 0) {
      this.showToast("No tienes cartas en la colección");
      return;
    }

    let csv = "\uFEFFCódigo,Nombre,Cantidad,Color,Type / Rasgos,Tipo,Rareza,Coste/Vida,Expansión,Fecha\n";
    this.collection.forEach(c => {
      csv += `"${c.id}","${(c.name || '').replace(/"/g, '""')}",${c.count},"${c.color}","${(c.traits || '').replace(/"/g, '""')}","${c.cardType || ''}","${c.rarity || ''}","${c.cost || ''}","${(c.set || '').replace(/"/g, '""')}","${c.addedAt || ''}"\n`;
    });

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `OnePiece_TCG_Coleccion_${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    this.showToast("📊 Archivo Excel CSV descargado");
  }

  handleExcelCSVImport(e) {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target.result;
      this.parseAndImportDelimitedText(content);
      e.target.value = '';
    };
    reader.readAsText(file);
  }

  parseAndImportDelimitedText(text) {
    if (!text || !text.trim()) return;

    const lines = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n').filter(l => l.trim().length > 0);
    if (lines.length === 0) {
      this.showToast("El archivo o texto está vacío");
      return;
    }

    let delimiter = ',';
    const firstLine = lines[0];
    if (firstLine.includes('\t')) {
      delimiter = '\t';
    } else if (firstLine.includes(';')) {
      delimiter = ';';
    }

    let importedCount = 0;
    let newCardsCount = 0;

    lines.forEach((line, idx) => {
      const cols = this.splitCSVLine(line, delimiter);
      if (cols.length === 0) return;

      const firstCol = cols[0].trim();
      if (idx === 0 && (firstCol.toLowerCase().includes('código') || firstCol.toLowerCase().includes('codigo') || firstCol.toLowerCase().includes('code') || firstCol.toLowerCase().includes('id'))) {
        return;
      }

      let cardCode = null;
      let qty = 1;

      for (let c of cols) {
        const cleaned = this.cleanCardCode(c);
        if (cleaned) {
          cardCode = cleaned;
          break;
        }
      }

      if (!cardCode && firstCol) {
        cardCode = this.cleanCardCode(firstCol) || firstCol.toUpperCase();
      }

      if (!cardCode || cardCode.length < 4) return;

      for (let c of cols) {
        const num = parseInt(c.trim());
        if (!isNaN(num) && num > 0 && num < 1000 && c.trim() !== cardCode && !c.includes('-')) {
          qty = num;
          break;
        }
      }

      const cardInfo = findOrGenerateCard(cardCode);
      
      if (cols.length >= 2 && cols[1] && cols[1].trim() && !this.cleanCardCode(cols[1])) {
        if (!cardInfo.name || cardInfo.name.startsWith("Carta ")) {
          cardInfo.name = cols[1].trim();
        }
      }

      const existingIndex = this.collection.findIndex(c => c.id === cardInfo.id);
      if (existingIndex >= 0) {
        this.collection[existingIndex].count += qty;
      } else {
        this.collection.unshift({
          ...cardInfo,
          count: qty,
          addedAt: new Date().toLocaleDateString()
        });
        newCardsCount++;
      }
      importedCount += qty;
    });

    this.saveCollection();
    this.renderAlbum();
    this.switchTab('album');
    this.showToast(`✅ ¡Importadas +${importedCount} copias (${newCardsCount} nuevas cartas)!`);
  }

  splitCSVLine(line, delimiter) {
    const result = [];
    let current = '';
    let inQuotes = false;

    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      if (char === '"') {
        inQuotes = !inQuotes;
      } else if (char === delimiter && !inQuotes) {
        result.push(current.trim());
        current = '';
      } else {
        current += char;
      }
    }
    result.push(current.trim());
    return result;
  }

  exportBackupJSON() {
    const blob = new Blob([JSON.stringify(this.collection, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `OnePiece_Backup_${new Date().toISOString().slice(0, 10)}.json`;
    link.click();
    this.showToast("💾 Respaldo JSON descargado");
  }

  importBackupJSON(e) {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const imported = JSON.parse(event.target.result);
        if (Array.isArray(imported)) {
          if (confirm(`¿Restaurar ${imported.length} cartas a tu álbum?`)) {
            imported.forEach(card => {
              this.addCardToCollection(card, card.count || 1);
            });
            this.showToast("¡Colección restaurada!");
            this.switchTab('album');
          }
        }
      } catch (err) {
        this.showToast("Error al procesar el archivo");
      }
    };
    reader.readAsText(file);
  }

  showToast(text) {
    const el = document.createElement('div');
    el.className = 'toast-notice';
    el.textContent = text;
    document.body.appendChild(el);

    setTimeout(() => {
      el.style.opacity = '0';
      el.style.transition = 'opacity 0.3s ease';
      setTimeout(() => el.remove(), 300);
    }, 2400);
  }
}

document.addEventListener('DOMContentLoaded', () => {
  window.app = new OnePieceApp();
});
